# Laborator: Partea 4 Alte module din biblioteca standard
# Student: <Talchiv Corina>


BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10

import time
import requests
import urllib.parse
import re
from html.parser import HTMLParser
import hashlib
import json
import socket
import ssl
import datetime
from typing import List, Tuple

#Exercitiul 35 Descompunerea unui URL
print("\n\033[35mExercitiul 35 \033[0m")
def parse_url_demo(url: str) -> None:
    parsed = urllib.parse.urlparse(url)
    print(f"URL: {url}")
    print(f"  - .scheme:   {parsed.scheme}")
    print(f"  - .netloc:   {parsed.netloc}")
    print(f"  - .path:     {parsed.path}")
    print(f"  - .query:    {parsed.query}")
    print(f"  - .fragment: {parsed.fragment}")

parse_url_demo("https://cybercor.org/path?x=1#top")

time.sleep(1)

#Exercitiul 36 Compunerea URL
print("\n\033[35mExercitiul 36\033[0m")
def build_absolute_urls(base: str, relative_paths: List[str]) -> List[str]:
    absolute_urls = []
    for path in relative_paths:
        abs_url = urllib.parse.urljoin(base,path)
        absolute_urls.append(abs_url)
    return absolute_urls
relative_links = ["/about", "contact.html", "../index.html"]
full_links =build_absolute_urls(BASE_URL,relative_links)
for rel, abs_url in zip(relative_links, full_links):
    print(f"Relativ: {rel:<15} -> Absolut: {abs_url}")
time.sleep(1)

#Exercitiul 37
print("\n\033[35mExercitiul 37\033[0m")
def extract_links(html: str) -> List[str]:
    pattern = r'href="([^"]+)"'
    raw_links = re.findall(pattern, html, flags=re.IGNORECASE)
    unique_links = []
    for link in raw_links:
        if link not in unique_links:
            unique_links.append(link)
    return unique_links
response_main = requests.get(BASE_URL, timeout=TIMEOUT)
page_links = extract_links(response_main.text)

print(f"S-au gasit {len(page_links)} legaturi unice, primele 5:")
for link in page_links[:5]:
    print(f" - {link}")
    time.sleep(1)

#Exercitiul 38 Interne sau externe?
print("\n\033[35mExercitiul 38\033[0m")
def split_links(links: List[str], base_url: str) -> Tuple[List[str], List[str]]:
    internal = []
    external = []
    target_domain = urllib.parse.urlparse(base_url).netloc
    
    for link in links:
        abs_url = urllib.parse.urljoin(base_url, link)
        link_domain = urllib.parse.urlparse(abs_url).netloc
        if link_domain == target_domain:
            internal.append(abs_url)
        else:
            external.append(abs_url)
            
    return internal, external  
internal_links, external_links = split_links(page_links, BASE_URL)
print(f"Legături interne ({len(internal_links)}): primele 3 -> {internal_links[:3]}")
print(f"Legături externe ({len(external_links)}): primele 3 -> {external_links[:3]}")
time.sleep(1)

# Exercitiul 39 Propriile metode 
print("\033[35mExercitiul 39\033[0m")

from html.parser import HTMLParser

class ImageFinder(HTMLParser):
    def __init__(self):
        super().__init__()
        self.images = []

    def handle_starttag(self, tag, attrs):
        # Transformam tag-ul in litere mici pentru a prinde si <IMG>
        if tag.lower() == "img":
            # Extragem atributul src
            src = dict(attrs).get("src")
            if src is not None:
                self.images.append(src)

# Testam functia
test_html = """ 
<html><body> 
  <img src="/logo.png" alt="Logo"> 
  <IMG SRC="steta-donkey-4014039.jpg"> 
  <img alt="imagine fara src"> 
  <img src="https://pixabay.com/ro/photos/" /> 
  <a href="/despre">Aceasta nu este o imagine</a> 
</body></html> 
"""

finder = ImageFinder()
finder.feed(test_html)
print("Lista test:", finder.images)

assert finder.images == [
    "/logo.png",                        # imagine obisnuita
    "steta-donkey-4014039.jpg",         # tag scris cu majuscule
    "https://pixabay.com/ro/photos/",   # tag care se inchide singur
], "Parserul nu a gasit exact imaginile asteptate"

print("Testul a trecut!\n")

# Cream un obiect NOU ImageFinder pentru pagina reala
try:
    response = requests.get(BASE_URL, timeout=10)
    finder_real = ImageFinder()
    finder_real.feed(response.text)
    print(len(finder_real.images), "imagini gasite pe site")
    # Afisam primele 10 imagini
    for src in finder_real.images[:10]:
        print(f" - {src}")
except requests.RequestException:
    print("Eroare la accesarea site-ului real")

time.sleep(1)

#Exercitiul 40 Amprenta paginii 
print("\n\033[35mExercițiul 40\033[0m")

def page_fingerprint(url: str) -> str:
    """Calculeaza si  returneaza amprenta SHA-256 a continutului unei pagini"""
    res = requests.get(url, timeout=TIMEOUT)
    return hashlib.sha256(res.content).hexdigest()

# se ruleaza  functia de doua ori si comparsm rezultatele
hash1 = page_fingerprint(BASE_URL)
time.sleep(1)
hash2 = page_fingerprint(BASE_URL)

print(f"Amprenta 1: {hash1}")
print(f"Amprenta 2: {hash2}")
print(f"Sunt identice? {hash1 == hash2}")
time.sleep(1)

#Comentarii
"""Rezultatul poate fi difeite in cazurile:
Continutul paginii se modifica in timp
Serverul returneaza reclame sau elemente dinamice diferite la fiecare cerere """

#Exercitiul 41. Salvare in JSON
print("\n\033[35mExercitiul 41\033[0m")

def save_and_load_headers(url: str, filename: str = "headers.json") -> None:
    res = requests.get(url, timeout=TIMEOUT) 
    # Salvare in fisier JSON
    with open(filename, "w", encoding="utf-8") as file:
        json.dump(dict(res.headers), file, indent=2)
    print(f"Antetele au fost salvate in '{filename}'")

   #incarcare inapoi din fisier se executa dupa inchiderea primului fisier
    with open(filename, "r", encoding="utf-8") as file:
        loaded_headers = json.load(file)
    sample_header = "Content-Type"
    print(f"Antet citit din JSON -> {sample_header}: {loaded_headers.get(sample_header)}")

save_and_load_headers(BASE_URL)
time.sleep(1)

#Exercitiul 42 Interogare DNS
print("\n\033[35mExercitiul 42\033[0m")
def resolve(hostname: str) -> str:
    if "://" in hostname:
        hostname = urllib.parse.urlparse(hostname).netloc
    return socket.gethostbyname(hostname)

domain = "cybercor.org"
ip_address = resolve(domain)
print(f"Adresa IP a domeniului {domain} este: {ip_address}")
time.sleep(1)

#Exercitiul 43 Expirarea certificatului SSL
print("\n\033[35mExercitiul 43\033[0m\n")
def cert_days_left(hostname: str) -> int:
    if "://" in hostname:
        hostname = urllib.parse.urlparse(hostname).netloc
        
    context = ssl.create_default_context()
    with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as ssock:
            cert = ssock.getpeercert()
            not_after_str = cert["notAfter"]
            expire_timestamp = ssl.cert_time_to_seconds(not_after_str)

            expire_date = datetime.datetime.fromtimestamp(expire_timestamp, tz=datetime.timezone.utc)
            now = datetime.datetime.now(datetime.timezone.utc)

            return (expire_date - now).days
        
days_remaining = cert_days_left("cybercor.org")
print(f"Zile ramase pana la expirarea certificatului SSL pentru cybercor.org: {days_remaining} zile")