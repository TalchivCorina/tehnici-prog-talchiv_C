# Laborator: Partea 2: Metode și atribute ale obuectelor web
# Student: <Talchiv Corina>
#Partea 2: Metode și atribute ale obiectelor web

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10

import requests
import time

#Exercițiul 9. Elementele de baza ale raspunsului
print("\033[35mExercitiul 9\033[0m")
response = requests.get(BASE_URL, timeout=TIMEOUT)
print(f"Status Code:{response.status_code} ")
print(f"OK: {response.ok}")
print(f"URL: {response.url}")
print(f"Encoding: {response.encoding}")
time.sleep(1)

#Exercițiul 10. Tratarea erorilor cu o metoda
print("\n\033[35mExercitiul 10\033[0m")
response.raise_for_status()
print("Pagina principala s-a incarcat cu succes")
invalid_url = BASE_URL + "/this-page-does-not-exist"
try:
    bad_response = requests.get(invalid_url, timeout=TIMEOUT)
    bad_response.raise_for_status()
except requests.HTTPError as err:
    print(f"Mesaj prietenos: Resursa nu a fost gasita pe server! Detalii eroare: {err}")
time.sleep(1)

#Exercițiul 11. Toate antetele
print("\n\033[35mExercitiul 11\033[0m")
print("Antetele raspunsului HTTP:")
for name, value in response.headers.items():
    print(f"{name}: {value}")
time.sleep(1)

#Exercițiul 12. Metode de dictionar
print("\n\033[35mExercitiul 12\033[0m")
server = response.headers.get("Server","lipeste")
content_type = response.headers.get("Content-Type", "lipeste")
contet_type_lower =response.headers.get("content-type", "lipeste")

print(f"Server:{server}")
print(f"Content-Type: {content_type}")
print(f"content-type: {contet_type_lower}")
#Comentarii
""""""
#Exercițiul 13.Inlatuirea metodelor de sir
print("\n\033[35mExercitiul 13\033[0m")
count_cyber =response.text.lower().count("cyber")
print(f"Cuvantul 'cyber' apare de {count_cyber} ori pe pagina principala")
#Comentarii
"""response.text - returneaza un obiect de tip de caracter, Metoda lower() este o metoda a clasei str si returneaza
alt sir de caractere convertiti in litere mici, rezultatul de asemenea este un str, putem 
apela imediat pe el metoda 'count("cyber")' destinata sirurile de caractere"""

#Exercițiul 14 Gasirea titlului 
print("\n\033[35mExercitiul 14\033[0m")
html_content = response.text
start_tag = ""
end_tag = ""

start_pos = html_content.find(start_tag)
if start_pos != -1:
    start_index = start_pos + len(start_tag)
    end_index = html_content.find(end_tag, start_index)
    
    title_text = html_content[start_index:end_index].strip()
    print(f"Titlul extras din pagină: '{title_text}'")
else:
    print("Tag-ul  nu a fost găsit în codul HTML")

time.sleep(1)

#Exercițiul 15 Numararea liniilor 
print("\n\033[35mExercitiul 15\033[0m")
lines = response.text.splitlines()
longest_line = max(lines,key=len) if lines else ""
print(f"Numar total de linii HTML: {len(lines)}")
print(f"Lungimea celei mai lungi linii: {len(longest_line)} caractere")
time.sleep(1)

#Exercițiul 16 Verificare HTTPS
print("\n\033[35mExercitiul 16\033[0m")
if response.url.startswith("https://"):
    print("Conexiune securizata")
else: print("Conexiune nesecurizata")
time.sleep(1)

#Exercițiul 17 Urmarirea redirectionarilor
print("\n\033[35mExercitiul 17\033[0m")
http_url = "http://cybercor.org"
redirect_response = requests.get(http_url, timeout=TIMEOUT)

if redirect_response.history:
    print("Istoric redirecționări:")
    for resp in redirect_response.history:
        print(f"  -> [{resp.status_code}] {resp.url}")
    print(f"URL final: {redirect_response.url}")
else: print(f"Nu au fost redirecționări. URL accesat: {redirect_response.url}")
time.sleep(1)

#Exercițiul 18 HEAD versus GET
print("\n\033[35mExercitiul 18\033[0m")
head_response = requests.head(BASE_URL,timeout=TIMEOUT)
time.sleep(1)
get_response =requests.get(BASE_URL,timeout=TIMEOUT)
print(f"Dimensiune corp la HEAD: {len(head_response.content)} octeti")
print(f"Dimensiune corp la GET: {len(get_response.content)} octeti")

#Comentarii
"""Cererea de tip HEAD solicita serverului doar atentele HTTP, fara corpul body resursei
Cererea GET descarca atat antetele, cat si intreh=gul corp HTML al paginii"""

#Exercițiul 19 Cookie-uri
print("\n\033[35mExercitiul 19\033[0m")
if response.cookies:
    print("Cookie-uri primite:")
    for cookie in response.cookies:
        print(f"  Cookie Nume: {cookie.name} | Securizat (.secure): {cookie.secure}")
else:
    print("Niciun cookie setat")
time.sleep(1)

#Exercițiul 20 Sesiuni
print("\n\033[35mExercitiul 20\033[0m")
custom_ua = "WebLab<Talchiv>"
session = requests.Session()
session.headers.update({"User-Agent":custom_ua})
echo_response =session.get(ECHO_URL + "/headers", timeout=TIMEOUT)
json_data = echo_response.json()

sent_user_agent =json_data.get("headers",{}).get("User-Agent")
print(f"User-Agent confirmat de httpbin.org: {sent_user_agent}")