# Laborator: Partea 3: Scrierea propriilor funcții
# Student: <Talchiv Corina>


BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10

import time
import requests
from typing import Dict,List,Optional

#Exercitiul 21 Prima functia
print("\n\033[35mExercitiul 21\033[0m")
def fetch(url: str) -> requests.Response:
 return requests.get(url,timeout=TIMEOUT)
resp_21 = fetch(BASE_URL)
print(f"Status Code pentru BASE_URL: {resp_21.status_code}")
time.sleep(1)

#Exercitiul 22 Returnarea unei singure valori
print("\n\033[35mExercitiul 22\033[0m")
def get_status(url: str) -> int:
  response = requests.get(url,timeout=TIMEOUT)
  return response.status_code
paths_to_check = ["/", "/robots.txt", "/sitemap.xml"]
for path in paths_to_check:
  full_url =BASE_URL + path
  status = get_status(full_url)
  print(f"Status pentru {path}: {status}")
  time.sleep(1)

#Exercitiul 23 Parametrii implicati

print("\n\033[35mExercitiul 23\033[0m")
def fetch_with_timeout(url: str, timeout: int = 10) -> requests.Response:
  return requests.get(url, timeout=timeout)
resp_default = fetch_with_timeout(BASE_URL)
print(f"Apel cu timeout implicit, Status: {resp_default.status_code}")
time.sleep(1)

#Exercitiul 24 O singura sarcina pe functie si docstring 
print("\n\033[35mExercitiul 24 && 25\033[0m")
def get_title(html: str) -> str:
  start_tag = "<title>"
  end_tag = "</title>"
  start_pos = html.find(start_tag)

  if start_pos != -1:
    start_index = start_pos + len(start_tag)
    end_index = html.find(end_tag, start_index)
    return html[start_index:end_index].strip()
  return "Titlu negasit"

extracted_title =get_title(resp_21.text)
print(f"Titlu extras: '{extracted_title}'")
print("\n Afisarea docstring cu help(get_title):")
help(get_title)

#Exercitiul 26 ADnotari de tip (Tye Hints)
print("\n\033[35mExercitiul 26\033[0m")
try:
  print("Incercare apel get_status(123):")
except Exception as e:
  print(f"Eroare la rulare:{e}")

"""Adnotarile de tip in python au rol pur informativ, ele nu opresc executia programului
la run daca apasam un argument de alt tip. Opresc erorile doar la nivel de analiza statica"""  

#Exercitiul 27 Fara opriri neasteptate
print("\n\033[35mExercitiul 27\033[0m")
def page_exists(url: str) -> bool:
  try:
    response = requests.get(url,timeout=TIMEOUT)
    return response.status_code == 200
  except requests.RequestException:
    return False
print(f"Exista {BASE_URL}? -> {page_exists(BASE_URL)}")
time.sleep(1)
invalid_domain = "https://this-domain-does-not-exist.invalid"
print(f"Exista {invalid_domain}? -> {page_exists(invalid_domain)}")
time.sleep(1)

#Exercitiul 28  Returnarea unui dictionar
print("\n\033[35mExercitiul 28\033[0m")
def check_paths(base: str, paths: List[str]) ->Dict[str,int]:
 results = {}
 for path in paths:
        full_url = base + path
        try:
            res = requests.get(full_url, timeout=TIMEOUT)
            results[path] = res.status_code
        except requests.RequestException:
            results[path] = 0
        time.sleep(1) 
 return results

paths_list = ["/", "/robots.txt", "/sitemap.xml"]
status_dict = check_paths(BASE_URL, paths_list)
print(f"Rezultat check_paths: {status_dict}")

 #Exercitiul 29 Argumente cu nume
print("\n\033[35mExercitiul 29\033[0m")
def get_header(url:str, name:str,default:str = "lipseste") -> str:
  try:
    res = requests.get(url,timeout=TIMEOUT)
    return res.headers.get(name,default)
  except requests.RequestException:
    return default
server_header =get_header(BASE_URL,name="Server")
print(f"Antetul Server pentru BASE_URL:{server_header}")
time.sleep(1)

#Exercitiul 30 Antete de securitate
print("\n\033[35mExercitiul 30\033[0m")
def security_headers(url: str) -> Dict[str, bool]:
    """Verifică prezența a 5 antete esențiale de securitate."""
    headers_to_check = [
        "Strict-Transport-Security",
        "Content-Security-Policy",
        "X-Frame-Options",
        "X-Content-Type-Options",
        "Referrer-Policy"
    ]
    
    try:
        res = requests.get(url, timeout=TIMEOUT)
        return {h: h in res.headers for h in headers_to_check}
    except requests.RequestException:
        return {h: False for h in headers_to_check}
sec_results = security_headers(BASE_URL)
print("Rezultate antete securitate:")
for header, present in sec_results.items():
    print(f"- {header}: {present}")

time.sleep(1)

#Exercitiul 31 Functii care apeleaza functii
print("\n\033[35mExercitiul 31\033[0m")
def score_headers(results: Dict[str, bool]) -> str:
   passed =sum(1 for val in results.values() if val)
   total = len(results)
   return f"{passed}/{total}"
score = score_headers(security_headers(BASE_URL))
print(f"Scor securitate antete pentru {BASE_URL}:{score}")
time.sleep(1)

#Exercitiul 32 Doua functii, o sarcina
print("\n\033[35mExercitiul 32\033[0m")
def fetch_robots(base: str) -> Optional[str]:
   robots_url = base + "/robots.txt" 
   try:
        res = requests.get(robots_url, timeout=TIMEOUT)
        if res.status_code == 200:
            return res.text
        return None
   except requests.RequestException:
        return None

def disallowed_paths(robots_text: Optional[str]) -> List[str]:
    if not robots_text:
        return []
    
    disallowed = []
    for line in robots_text.splitlines():
        line = line.strip()
        if line.startswith("Disallow:"):
            parts = line.split(":", 1)
            if len(parts) > 1:
                path = parts[1].strip()
                if path:
                    disallowed.append(path)
    return disallowed
robots_content = fetch_robots(BASE_URL)
disallowed_list = disallowed_paths(robots_content)
print(f"Cai interzise disallow găsite în robots.txt: {disallowed_list}")

time.sleep(1)

#Exercitiul 33 Oricate argumente (*args)
print("\n\033[35mExercitiul 33\033[0m")
def response_times(*urls: str) -> Dict[str,float]:
   times = {}
   for url in urls:
      try:
         start =time.perf_counter()
         requests.get(url, timeout=TIMEOUT)
         duration = time.perf_counter() - start
         times[url] = round(duration,4)
      except requests.RequestException:
         times[url] = -1.0
         time.sleep(1)
      return times
durations = response_times(BASE_URL,ECHO_URL)
print(f"Timpi de raspuns *urls: {durations}")

#Exercitiul 34 Argumente cu nume colectate **kwargs
print("\n\033[35mExercitiul 34\033[0m")
def log(message: str,**details) -> None:
   details_str = " | ".join(f"{k}={v}" for k, v in details.items())
   if details_str:
    print(f"{message} | {details_str}")
   else:
    print(message)
log("verificat",url=BASE_URL,status=200)
