#Laborator: Construirea propriului modul
#Student: Talchiv Corina

import argparse
import csv
import datetime

# Exercitiul 45 & 47: Importarea numelor specifice din modul
from webtools import (
    fetch, 
    get_title, 
    security_headers, 
    DEFAULT_HEADERS, 
    site_report, 
    get_status
)

# Comentarii
"""Daca main.py ar avea o functie proprie numita get_title, functia importata
 din webtools ar fi suprascrisa (shadowed) de functia locala, daca importul
este scris inainte, sau invers """

def main():
    # Exercitiul 48: Argumente din linia de comandă
    parser = argparse.ArgumentParser(description="Instrument de analiza web.")
    parser.add_argument("url", nargs="?", default="https://cybercor.org", help="URL-ul de analizat")
    args = parser.parse_args()

    target_url = args.url

    print(f"Se utilizeaza User-Agent: {DEFAULT_HEADERS}\n")

    # Exercitiul 44 & 45: Testare functii importate
    res = fetch(target_url)
    title = get_title(res.text)
    print(f"Titlu extras: {title}")

    # Exercitiul 49: Un raport CSV
    paths_to_check = ["/", "/admin", "/login", "/robot.txt"]
    with open("report.csv", "w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(["path", "status", "checked_at"])
        for path in paths_to_check:
            full_url = target_url.rstrip("/") + path
            status = get_status(full_url)
            timestamp = datetime.datetime.now().isoformat()
            writer.writerow([path, status, timestamp])
    print("Rezultatele verificarii cailor au fost salvate in report.csv\n")

    # Exercitiul 50: Generarea raportului complet JSON
    site_report(target_url)

if __name__ == "__main__":
    main()