# Laborator: Partea 5 Construirea propriului modul
# Student: <Talchiv Corina>

import requests
import urllib.parse
import re
from html.parser import HTMLParser
import hashlib
import json
import socket
import ssl
import datetime
from typing import List, Tuple, Dict, Any

from bs4 import BeautifulSoup

# Exercitiul 47: Constanta de modul
DEFAULT_HEADERS = {"User-Agent": "WebLa-Talchiv Corina"}
TIMEOUT = 10

def fetch(url: str, headers: dict = None) -> requests.Response:
    if headers is None:
        headers = DEFAULT_HEADERS
    return requests.get(url, headers=headers, timeout=TIMEOUT)

def get_status(url: str) -> int:
    try:
        res = fetch(url)
        return res.status_code
    except requests.RequestException:
        return 0

def get_title(html: str) -> str:
    if not html:
        return "Fara titlu"
    soup = BeautifulSoup(html, "html.parser")
    title_tag = soup.find("title")
    if title_tag and title_tag.string:
        return title_tag.string.strip()
    return "Fara titlu"

def security_headers(url: str) -> Dict[str, bool]:
    headers_to_check = [
        "Strict-Transport-Security",
        "Content-Security-Policy",
        "X-Frame-Options",
        "X-Content-Type-Options",
        "Referrer-Policy"
    ]
    try:
        res = fetch(url)
        return {h: h in res.headers for h in headers_to_check}
    except requests.RequestException:
        return {h: False for h in headers_to_check}

def resolve(hostname: str) -> str:
    if "://" in hostname:
        hostname = urllib.parse.urlparse(hostname).netloc
    try:
        return socket.gethostbyname(hostname)
    except socket.gaierror:
        return "N/A"

def cert_days_left(hostname: str) -> int:
    if "://" in hostname:
        hostname = urllib.parse.urlparse(hostname).netloc
    context = ssl.create_default_context()
    try:
        with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
            with context.wrap_socket(sock, server_hostname=hostname) as ssock:
                cert = ssock.getpeercert()
                not_after_str = cert["notAfter"]
                expire_timestamp = ssl.cert_time_to_seconds(not_after_str)
                expire_date = datetime.datetime.fromtimestamp(expire_timestamp, tz=datetime.timezone.utc)
                now = datetime.datetime.now(datetime.timezone.utc)
                return (expire_date - now).days
    except Exception:
        return 0

def extract_links(html: str) -> List[str]:
    if not html:
        return []
    soup = BeautifulSoup(html, "html.parser")
    unique_links = []
    
    for a_tag in soup.find_all("a", href=True):
        href = a_tag["href"].strip()
        if href and href not in unique_links:
            unique_links.append(href)
            
    return unique_links

def split_links(links: List[str], base_url: str) -> Tuple[List[str], List[str]]:
    internal, external = [], []
    target_domain = urllib.parse.urlparse(base_url).netloc
    for link in links:
        abs_url = urllib.parse.urljoin(base_url, link)
        link_domain = urllib.parse.urlparse(abs_url).netloc
        if link_domain == target_domain:
            internal.append(abs_url)
        else:
            external.append(abs_url)
    return internal, external

def get_disallowed_paths(base_url: str) -> List[str]:
    robots_url = urllib.parse.urljoin(base_url, "/robots.txt")
    disallowed = []
    try:
        res = fetch(robots_url)
        if res.status_code == 200:
            for line in res.text.splitlines():
                if line.lower().startswith("disallow:"):
                    path = line.split(":", 1)[1].strip()
                    if path:
                        disallowed.append(path)
    except requests.RequestException:
        pass
    return disallowed

# Exercitiul 50: Functia complexa site_report(url)
def site_report(url: str) -> Dict[str, Any]:
    print(f"=== Raport site: {url} ===")
    
    #Status si URL final
    try:
        res = fetch(url)
        status_code = res.status_code
        final_url = res.url
        html_text = res.text
    except requests.RequestException:
        status_code = 0
        final_url = url
        html_text = ""

    #Titlul paginii
    title = get_title(html_text)
    #  Adresa IP
    ip_addr = resolve(url)
    #Redirectionari pornind de la http://
    http_url = url.replace("https://", "http://")
    try:
        res_redir = requests.get(http_url, timeout=TIMEOUT, allow_redirects=True)
        if res_redir.history:
            redir_str = " -> ".join([f"{r.status_code}" for r in res_redir.history]) + f" -> {res_redir.url}"
        else:
            redir_str = "Fara redirectionari"
    except Exception:
        redir_str = "Eroare la verificare"

    #Scorul antetelor de securitate
    sec_hdr = security_headers(url)
    sec_score = f"{sum(sec_hdr.values())}/{len(sec_hdr)}"

    #Certificat SSL
    days_left = cert_days_left(url)

    #Legaturi
    links = extract_links(html_text)
    internal, external = split_links(links, url)

    #Cai interzise in robots.txt
    disallowed = get_disallowed_paths(url)

    # Afisare pe ecran
    print(f"Cod de stare:      {status_code}")
    print(f"Titlu:             {title}")
    print(f"Adresă IP:         {ip_addr}")
    print(f"Redirectionari:    {redir_str}")
    print(f"Scor securitate:   {sec_score}")
    print(f"Certificat:        {days_left} de zile ramase")
    print(f"Legaturi:          {len(internal)} interne, {len(external)} externe")
    print(f"Cai interzise:     {', '.join(disallowed) if disallowed else 'Niciuna'}")

    report_data = {
        "url": url,
        "status_code": status_code,
        "final_url": final_url,
        "title": title,
        "ip_address": ip_addr,
        "redirects": redir_str,
        "security_score": sec_score,
        "cert_days_left": days_left,
        "internal_links_count": len(internal),
        "external_links_count": len(external),
        "disallowed_paths": disallowed
    }

    # Salvare in report.json
    with open("report.json", "w", encoding="utf-8") as f:
        json.dump(report_data, f, indent=2, ensure_ascii=False)
    
    print("Salvat in report.json\n")
    return report_data

# Exercițiul 46: Blocul main (se execută doar la 'python webtools.py')
if __name__ == "__main__":
    print("Autotest:", get_status("https://cybercor.org"))