#Laborator: Partea 1: Importuri
#Student: Talchiv Corina

BASE_URL ="https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10 # secunde

import time
#Exercitiul 1. Primul import

import requests
import urllib.request

print("\033[35mExercitiul 1\033[0m")
print(f"Versiunea bibliotecii requests: {requests.__version__}")

#Comentarii 
""" urllib este un modul integrat in python de aceea este instalat
odata cu python si nu necesita instalare, in schimb 'requests'
este o biblioteca terta , care trebuie descaracata separat din managerul pip"""
time.sleep(1)

#Exercitiul 2. Doua stiluri de import 

print("\033[35mExercitiul 2\033[0m")
response_style1 = requests.get(BASE_URL, timeout=TIMEOUT)
print(f"Stil 1 -requests.get -> Cod de stare: {response_style1.status_code}" )
from requests import get
response_style2 = get(BASE_URL, timeout=TIMEOUT)
print(f"Stilul 2 - from requests import get -> Code de stare: {response_style2.status_code}")

#Comentarii 
"""Avantaj stil 1, ofera claritate explicita in tot codul, evidentiaza sursa functei
si ecita conflictele de nume
Avantaj stil 2, scurteaza sintaxa,oferind un cod mai curat,cand este folosit o functie mai des"""
time.sleep(1)

#Exercitiul 3. Alias-uri

print("\033[35mExercitiul 3\033[0m")
import requests as rq

response_alias = rq.get(BASE_URL, timeout=TIMEOUT)
print(f"Pagina descarcata cu alias rq -> Cod de stare: {response_alias.status_code}")

#Comentarii
""" Cand face codul mai usor de citit:In cazul modulelor,bibliotecilor cu nume lungi sau foarte des folosite in comunitate, de exmplu
import numpy as np, unde conversatiile sunt recunoscute universal
Cand il face mai greu de citit: cand se folosesc alias-uri nestandardizate, criptice
sau de o singura litera de exemplu import requests as r, provocand confuzie pentru altii
dezvoltatori care citesc codul"""


#Exercitiul 4. Doar biblioteca standard

print("\033[35mExercitiul 4\033[0m")
headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
}
req = urllib.request.Request(BASE_URL, headers=headers)

with urllib.request.urlopen(req, timeout=TIMEOUT) as response:
    status_code = response.status
    body_bytes = response.read()
    body_text = body_bytes.decode("utf-8")
    
    print(f"Status urllib: {status_code}")
    print(f"Primele 200 caractere din corp:\n{body_text[:200]}")

time.sleep(1)

#Exercitiul 5. Priviti in interiorul unui modul

print("\033[35mExercitiul 5\033[0m")
print("Afisare dir(requests) (trunchiata pentru lizibilitate):")
print(dir(requests)[:10])

#Comentarii
"""get este o functie folosita oentru trimiterea cererilor HTTP GET
Response este o clasa instantiata cand primim un raspuns HTTP
exceptions este modul subordonat, ce contine clasele de erori HTTP"""

print("\033[35mExercitiul 6\033[0m")
response_timeout = requests.get(BASE_URL,timeout=TIMEOUT)
print(f"Cerere executa cu parametrii timeout={TIMEOUT}s Status: {response_timeout.status_code}" )


#Exercitiul 7. Cronometrarea unei cereri 

print("\033[35mExercitiul 7\033[0m")
t_start = time.perf_counter()
response_time_test =requests.get(BASE_URL,timeout=TIMEOUT)
t_end = time.perf_counter()

total_duration = t_end - t_start
elapsed_seconds = response_time_test.elapsed.total_seconds()

print(f"Timp masurat cu time.pref_counter(): {total_duration:.4f} secunde")
print(f"Timp inregistrat in response.elapsed: {elapsed_seconds:.4} secunde")

#Comentarii
"""time.pref_counter() masoara tot timpul scurs din perspectiva sistemului local, face 
procesarea pe server si timpul de lecenta/procesarea locala -> rezolvarea DNS, trimiterea ceririilor
response.elapsed masoara doar timpul scurs de la trimiterea ultimului octet al
cererii de catre client pana la primirea primilor octeti ai antetului de raspuns"""

print("\033[35mExercitiul 8\033[0m")
try:
    import base64
    print("Modulul bs4 este instalat!")
except ImportError:
    print("Instalati modulul cu pip install beautifulsoup4")